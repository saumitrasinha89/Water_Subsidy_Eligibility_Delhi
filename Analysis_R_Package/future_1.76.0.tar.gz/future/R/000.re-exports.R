#' Functions Moved to 'parallelly'
#'
#' The following function used to be part of \pkg{future}, but has since
#' been migrated to \pkg{parallelly}. The migration started with
#' \pkg{future} 1.20.0 (November 2020). They were moved because they
#' are also useful outside of the \pkg{future} framework.
#'
#' _If you are using any of these from the \pkg{future} package, please
#'  switch to use the ones from the \pkg{parallelly} package. Thank you!_
#'
#' * [parallelly::availableCores()]
#    Used by: ale (1), BatchGetSymbols (2), codalm (1), cft (1), deseats (3),
#             elevatr (1), heterogen, PINstimation (1), powRICLPM (1),
#             readsdr (1), recforest (3), sigminer (2), skpr (1), smoots (3),
#             TriDimRegression (1), uci (1)
#             [2025-12-22, 2026-01-31, 2026-04-04]
#' * [parallelly::availableWorkers()]
#    Used by: wqspt (1) [2025-03-15, 2026-02-01, 2026-08-03]
#' * [parallelly::makeClusterPSOCK()]
#    Used by: eatRep (1), ivDiag (1) [2026-04-20]
#' * [parallelly::supportsMulticore()]
#    Used by: LandComp (1), polarisR (1) [2026-04-16]
#
#  (1) Issue filed or PR sent
#  (2) In the next release
#  (3) Has no online issue tracker
#' 
#' For backward-compatible reasons, _some_ of these functions remain
#' available as exact copies also from this package (as re-exports), e.g.
#'
#' ```r
#' cl <- parallelly::makeClusterPSOCK(2)
#' ```
#'
#' can still be accessed as:
#'
#' ```r
#' cl <- future::makeClusterPSOCK(2)
#' ```
#'
#' _Note that it is the goal to remove all of the above from this package._
#'
#'
#' @importFrom parallelly availableCores
#' @export availableCores
#' @aliases availableCores
#'
#' @importFrom parallelly availableWorkers
#' @export availableWorkers
#' @aliases availableWorkers
#'
#' @importFrom parallelly makeClusterPSOCK
#' @export makeClusterPSOCK
#' @aliases makeClusterPSOCK
#'
#' @importFrom parallelly supportsMulticore
#' @export supportsMulticore
#' @aliases supportsMulticore
#'
#' @name re-exports
#' @keywords internal
NULL
